﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace BehaviorTest
{
    /// <summary>
    /// Interaction logic for FadeInAndOutTest.xaml
    /// </summary>
    public partial class FadeInAndOutTest : Window
    {
        public FadeInAndOutTest()
        {
            InitializeComponent();
        }
    }
}
