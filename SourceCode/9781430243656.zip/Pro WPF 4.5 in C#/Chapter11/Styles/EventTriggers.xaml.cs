using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Styles
{
    /// <summary>
    /// Interaction logic for EventTriggers.xaml
    /// </summary>

    public partial class EventTriggers : System.Windows.Window
    {

        public EventTriggers()
        {
            InitializeComponent();
        }

    }
}